/**
  ******************************************************************************
  * @file    motor.c
  * @brief   Open-loop sinusoidal V/f drive on TIM1, six complementary outputs.
  *
  * This module owns TIM1 and the six PWM pins outright, at register level. It
  * deliberately overwrites whatever MX_TIM1_Init()/MX_TIM3_Init() configured,
  * so it stays correct even if the .ioc is regenerated with the old settings.
  ******************************************************************************
  */
#include "motor.h"

#define SIN_N        256u
#define PHASE_120    1431655765u          /* 2^32 / 3                          */

static float        s_sin[SIN_N];
static volatile mot_state_t s_state   = MOT_IDLE;
static volatile uint32_t    s_isr     = 0;
static volatile uint32_t    s_faults  = 0;
static volatile float       s_m       = 0.0f;

static uint32_t     s_theta    = 0;       /* electrical angle, 32-bit wrap     */
static float        s_f        = 0.0f;    /* present electrical Hz             */
static float        s_f_target = 0.0f;    /* commanded electrical Hz           */
static float        s_df       = 0.0f;    /* Hz added per ISR during ramp      */
static float        s_phase_k  = 0.0f;    /* 2^32 / fsw, angle step per Hz     */
static float        s_inv_fbase = 0.0f;   /* 1 / MOT_F_BASE_HZ                 */
static uint8_t      s_flt_cnt  = 0;

static uint32_t     s_timclk   = 0;
static uint32_t     s_arr      = 0;
static uint32_t     s_dtg      = 0;
static uint32_t     s_ccr_min  = 0;
static uint32_t     s_ccr_max  = 0;

/* -------------------------------------------------------------------------- */
/* helpers                                                                    */
/* -------------------------------------------------------------------------- */

/* TIM1 lives on APB2. HAL_RCC_GetPCLK2Freq() reports the bus clock; the timer
 * clock is doubled whenever the APB2 prescaler is not 1. */
static uint32_t tim1_clock(void)
{
  uint32_t f = HAL_RCC_GetPCLK2Freq();
  uint32_t ppre2 = (RCC->CFGR & RCC_CFGR_PPRE2) >> RCC_CFGR_PPRE2_Pos;
  if (ppre2 >= 4u) { f *= 2u; }         /* 0xx = div1, 1xx = divided          */
  return f;
}

/* nanoseconds -> timer counts, rounded up so we never undershoot a minimum */
static uint32_t ns_to_counts(uint32_t ns, uint32_t clk_hz)
{
  uint32_t mhz = clk_hz / 1000000u;
  return (ns * mhz + 999u) / 1000u;
}

/* Build sin(2*pi*i/256) by rotating a unit phasor. Avoids pulling in libm. */
static void sin_table_build(void)
{
  const double c = 0.99969881869620425;   /* cos(2*pi/256) */
  const double s = 0.02454122852291228;   /* sin(2*pi/256) */
  double x = 1.0, y = 0.0;
  for (uint32_t i = 0; i < SIN_N; i++)
  {
    s_sin[i] = (float)y;
    double nx = x * c - y * s;
    double ny = x * s + y * c;
    x = nx; y = ny;
  }
}

static inline float sin_lookup(uint32_t theta)
{
  return s_sin[theta >> 24];              /* top 8 bits index the table       */
}

/* Duty (0..1) -> CCR, respecting the minimum input pulse width of the driver.
 *
 * Centre-aligned: high-side on-time = 2*CCR - DTG counts, low-side on-time =
 * 2*(ARR-CCR) - DTG. Below s_ccr_min we snap to 0: the high side then gets no
 * pulse at all (legal) and the low side conducts the whole period, which also
 * tops the bootstrap cap up. Above s_ccr_max the low side would stop being on
 * long enough to refresh that cap, and the high side drops out a few cycles
 * later -- so that clamp is the one that actually matters. */
static inline uint32_t duty_to_ccr(float d)
{
  int32_t v = (int32_t)(d * (float)s_arr + 0.5f);
  if (v < (int32_t)s_ccr_min) { return 0u; }
  if (v > (int32_t)s_ccr_max) { return s_ccr_max; }
  return (uint32_t)v;
}

static void outputs_off(void)
{
  TIM1->BDTR &= ~TIM_BDTR_MOE;            /* OSSI drives HIN and LIN low      */
  TIM1->CCR1 = 0; TIM1->CCR2 = 0; TIM1->CCR3 = 0;
}

/* -------------------------------------------------------------------------- */
/* init                                                                       */
/* -------------------------------------------------------------------------- */

static void pins_park_low(void)
{
  /* Drive all six driver inputs low as plain GPIO before the timer takes them,
   * so they are never floating while TIM1 is being configured. */
  GPIO_InitTypeDef g = {0};
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10,
                    GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0 | GPIO_PIN_1, GPIO_PIN_RESET);

  g.Mode  = GPIO_MODE_OUTPUT_PP;
  g.Pull  = GPIO_NOPULL;
  g.Speed = GPIO_SPEED_FREQ_LOW;
  g.Pin   = GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10;
  HAL_GPIO_Init(GPIOA, &g);
  g.Pin   = GPIO_PIN_0 | GPIO_PIN_1;
  HAL_GPIO_Init(GPIOB, &g);
}

static void pins_to_tim1(void)
{
  GPIO_InitTypeDef g = {0};
  g.Mode      = GPIO_MODE_AF_PP;
  g.Pull      = GPIO_NOPULL;
  g.Speed     = GPIO_SPEED_FREQ_HIGH;     /* not VERY_HIGH: calmer edges       */
  g.Alternate = GPIO_AF6_TIM1;

  g.Pin = GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10;
  HAL_GPIO_Init(GPIOA, &g);               /* CH1N, CH1, CH2, CH3               */
  g.Pin = GPIO_PIN_0 | GPIO_PIN_1;
  HAL_GPIO_Init(GPIOB, &g);               /* CH2N, CH3N                        */
}

static void driver_pins_init(void)
{
  GPIO_InitTypeDef g = {0};
  (void)g;

  /* STBY/SD/FLT are #defines, so they could be on any port. Enabling all four
   * banks costs a few microamps and removes the silent-failure mode where a
   * GPIO write goes nowhere because its clock was never turned on. */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

#ifdef MOT_FLT_PORT
  g.Mode  = GPIO_MODE_INPUT;
  g.Pull  = GPIO_PULLUP;                  /* open-drain, active low            */
  g.Pin   = MOT_FLT_PIN;
  HAL_GPIO_Init(MOT_FLT_PORT, &g);
#endif

#ifdef MOT_SD_PORT
  /* Shared with the smartSD open-drain output of the driver and its external
   * RC. Must be open-drain here or we would fight the hardware trip. */
  HAL_GPIO_WritePin(MOT_SD_PORT, MOT_SD_PIN, GPIO_PIN_SET);
  g.Mode  = GPIO_MODE_OUTPUT_OD;
  g.Pull  = GPIO_NOPULL;
  g.Speed = GPIO_SPEED_FREQ_LOW;
  g.Pin   = MOT_SD_PIN;
  HAL_GPIO_Init(MOT_SD_PORT, &g);
#endif

#ifdef MOT_STBY_PORT
  HAL_GPIO_WritePin(MOT_STBY_PORT, MOT_STBY_PIN, GPIO_PIN_RESET);
  g.Mode  = GPIO_MODE_OUTPUT_PP;
  g.Pull  = GPIO_NOPULL;
  g.Speed = GPIO_SPEED_FREQ_LOW;
  g.Pin   = MOT_STBY_PIN;
  HAL_GPIO_Init(MOT_STBY_PORT, &g);
#endif
}

static void tim1_init(void)
{
  __HAL_RCC_TIM1_CLK_ENABLE();

  TIM1->CR1  = 0;                         /* stop the counter to reconfigure   */
  TIM1->BDTR = 0;                         /* MOE off                           */
  TIM1->DIER = 0;
  TIM1->CR2  = 0;                         /* OISx = 0 -> idle level is LOW     */

  TIM1->PSC  = 0;
  TIM1->ARR  = s_arr;
  TIM1->CNT  = 0;

  /* Centre-aligned generates an update event at BOTH overflow and underflow.
   * RCR = 1 makes that one interrupt per PWM period instead of two. The
   * loop-rate print in main() is there to confirm this on real hardware. */
  TIM1->RCR  = 1;

  /* PWM mode 1 on CH1..CH3, with preload so duty updates land atomically. */
  TIM1->CCMR1 = (6u << TIM_CCMR1_OC1M_Pos) | TIM_CCMR1_OC1PE
              | (6u << TIM_CCMR1_OC2M_Pos) | TIM_CCMR1_OC2PE;
  TIM1->CCMR2 = (6u << TIM_CCMR2_OC3M_Pos) | TIM_CCMR2_OC3PE;

  TIM1->CCR1 = 0; TIM1->CCR2 = 0; TIM1->CCR3 = 0;

  /* Enable high and low side of each phase. Hardware inserts the dead time
   * and interlocks the pair -- exactly what a second timer could not give. */
  TIM1->CCER = TIM_CCER_CC1E | TIM_CCER_CC1NE
             | TIM_CCER_CC2E | TIM_CCER_CC2NE
             | TIM_CCER_CC3E | TIM_CCER_CC3NE;
#if MOT_LIN_INVERTED
  TIM1->CCER |= TIM_CCER_CC1NP | TIM_CCER_CC2NP | TIM_CCER_CC3NP;
#endif

  /* OSSI: whenever MOE = 0, both HIN and LIN are actively driven to their idle
   * level (low) rather than released. A floating gate-driver input on a
   * disabled bridge is not a state worth having. */
  TIM1->BDTR = (s_dtg & TIM_BDTR_DTG) | TIM_BDTR_OSSI;

  TIM1->CR1 = TIM_CR1_ARPE | (1u << TIM_CR1_CMS_Pos);   /* centre-aligned M1   */

  TIM1->EGR = TIM_EGR_UG;                 /* push preloaded values through     */
  TIM1->SR  = 0;
  TIM1->DIER = TIM_DIER_UIE;

  NVIC_SetPriority(TIM1_UP_TIM16_IRQn, 1);
  NVIC_EnableIRQ(TIM1_UP_TIM16_IRQn);

  TIM1->CR1 |= TIM_CR1_CEN;               /* counting, but MOE still off       */
}

void motor_init(void)
{
  s_timclk  = tim1_clock();
  s_arr     = s_timclk / (2u * MOT_PWM_HZ);          /* centre-aligned         */
  s_dtg     = ns_to_counts(MOT_DEADTIME_NS, s_timclk);
  if (s_dtg > 127u) { s_dtg = 127u; }     /* BDTR range 0 encoding             */

  uint32_t min_pulse = ns_to_counts(MOT_MIN_PULSE_NS, s_timclk);
  s_ccr_min = (min_pulse + s_dtg + 1u) / 2u;
  s_ccr_max = (s_arr > s_ccr_min) ? (s_arr - s_ccr_min) : 0u;

  s_phase_k   = 4294967296.0f / (float)MOT_PWM_HZ;
  s_inv_fbase = 1.0f / MOT_F_BASE_HZ;
  s_df      = MOT_RAMP_HZ_PER_S / (float)MOT_PWM_HZ;

  sin_table_build();
  pins_park_low();
  driver_pins_init();
  tim1_init();
  pins_to_tim1();

#ifdef MOT_STBY_PORT
  HAL_GPIO_WritePin(MOT_STBY_PORT, MOT_STBY_PIN, GPIO_PIN_SET);
  HAL_Delay(2);                           /* let the driver leave standby      */
#endif

  s_state = MOT_IDLE;
}

/* -------------------------------------------------------------------------- */
/* control                                                                    */
/* -------------------------------------------------------------------------- */

bool motor_flt_asserted(void)
{
#ifdef MOT_FLT_PORT
  return (HAL_GPIO_ReadPin(MOT_FLT_PORT, MOT_FLT_PIN) == GPIO_PIN_RESET);
#else
  return false;
#endif
}

bool motor_start(void)
{
  outputs_off();
  s_state   = MOT_IDLE;                   /* keeps the ISR off the CCRs        */
  s_flt_cnt = 0;

#ifdef MOT_SD_PORT
  HAL_GPIO_WritePin(MOT_SD_PORT, MOT_SD_PIN, GPIO_PIN_SET);
#endif
  HAL_Delay(1);                           /* let SD release and FLT settle     */

  /* Check the fault line BEFORE enabling the outputs. If the driver is already
   * unhappy -- VCC below UVLO, thermal, a latched smartSD trip -- there is no
   * point switching, and tripping 30 us into the run tells you much less than
   * refusing to start does. */
  if (motor_flt_asserted())
  {
    s_state = MOT_FAULT;
    s_faults++;
    return false;                         /* MOE stays off                     */
  }

  /* Bootstrap precharge. All three CCRs at 0 means all three low sides on for
   * the full period. Skip this and the boot caps are flat, the high sides
   * never turn on, and the motor just hums -- the single most common reason a
   * bridge like this refuses to spin. */
  TIM1->CCR1 = 0; TIM1->CCR2 = 0; TIM1->CCR3 = 0;
  TIM1->EGR  = TIM_EGR_UG;
  TIM1->SR   = 0;
  TIM1->BDTR |= TIM_BDTR_MOE;
  HAL_Delay(MOT_PRECHARGE_MS);

  s_theta = 0;
  s_f     = MOT_F_MIN_HZ;
  s_m     = MOT_M_BOOST;
  s_state = MOT_RUN;
  return true;
}

void motor_stop(void)
{
  s_state = MOT_IDLE;
  outputs_off();
}

void motor_set_speed_hz(float f)
{
  /* Ceiling of fsw/20 keeps at least 20 PWM periods per electrical cycle (the
   * modulation is meaningless below that) and, incidentally, keeps
   * s_f * s_phase_k inside uint32 range in the ISR. */
  const float f_max = (float)MOT_PWM_HZ / 20.0f;
  if (f < 0.0f)   { f = 0.0f; }
  if (f > f_max)  { f = f_max; }
  s_f_target = f;
}

void motor_set_speed_rpm(float rpm)
{
  motor_set_speed_hz(rpm * (float)MOT_POLE_PAIRS / 60.0f);
}

mot_state_t motor_state(void)      { return s_state; }
float       motor_speed_hz(void)   { return s_f; }
float       motor_speed_rpm(void)  { return s_f * 60.0f / (float)MOT_POLE_PAIRS; }
float       motor_modulation(void) { return s_m; }
uint32_t    motor_faults(void)     { return s_faults; }
uint32_t    motor_isr_count(void)  { return s_isr; }
uint32_t    motor_arr(void)        { return s_arr; }
uint32_t    motor_ccr_min(void)    { return s_ccr_min; }
uint32_t    motor_ccr_max(void)    { return s_ccr_max; }
uint32_t    motor_timclk(void)     { return s_timclk; }
uint32_t    motor_dtg(void)        { return s_dtg; }

/* -------------------------------------------------------------------------- */
/* modulator -- runs once per PWM period                                      */
/* -------------------------------------------------------------------------- */

void TIM1_UP_TIM16_IRQHandler(void)
{
  if ((TIM1->SR & TIM_SR_UIF) == 0u) { return; }
  TIM1->SR = ~TIM_SR_UIF;                 /* rc_w0: clear UIF, touch nothing   */

  s_isr++;

  if (s_state != MOT_RUN) { return; }

#ifdef MOT_FLT_PORT
  /* Debounced so switching noise on an open-drain line cannot nuisance-trip.
   * Direct IDR read rather than HAL_GPIO_ReadPin(): this runs 30000 times a
   * second and the HAL version is a real function call. */
  if ((MOT_FLT_PORT->IDR & MOT_FLT_PIN) == 0u)
  {
    if (++s_flt_cnt >= 4u)
    {
      outputs_off();
      s_state = MOT_FAULT;
      s_faults++;
      return;
    }
  }
  else { s_flt_cnt = 0; }
#endif

  /* frequency slew */
  if      (s_f < s_f_target) { s_f += s_df; if (s_f > s_f_target) s_f = s_f_target; }
  else if (s_f > s_f_target) { s_f -= s_df; if (s_f < s_f_target) s_f = s_f_target; }

  /* V/f: volts proportional to frequency, plus a floor to cover winding IR.
   * Reciprocal is precomputed -- VDIV.F32 is ~14 cycles and this is the only
   * divide left in the loop. */
  float m = MOT_M_BOOST + (MOT_M_MAX - MOT_M_BOOST) * (s_f * s_inv_fbase);
  if (m > MOT_M_MAX) { m = MOT_M_MAX; }
  if (m < 0.0f)      { m = 0.0f; }
  s_m = m;

  s_theta += (uint32_t)(s_f * s_phase_k);

  float a = m * sin_lookup(s_theta);
  float b = m * sin_lookup(s_theta - PHASE_120);
  float c = m * sin_lookup(s_theta + PHASE_120);

  /* Min-max (third harmonic) injection. Common-mode only, so the motor never
   * sees it, but it buys ~15% more line-to-line volts out of the same bus.
   * On a 12 V bus that is worth having. */
  float mx = (a > b) ? a : b; if (c > mx) { mx = c; }
  float mn = (a < b) ? a : b; if (c < mn) { mn = c; }
  float off = 0.5f * (mx + mn);
  a -= off; b -= off; c -= off;

  TIM1->CCR1 = duty_to_ccr(0.5f + 0.5f * a);
  TIM1->CCR2 = duty_to_ccr(0.5f + 0.5f * b);
  TIM1->CCR3 = duty_to_ccr(0.5f + 0.5f * c);
}
