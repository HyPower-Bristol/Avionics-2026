/**
  ******************************************************************************
  * @file    motor.h
  * @brief   Open-loop V/f BLDC drive for EVLGANSPIN2-3PH running at 12 V.
  *
  * Bypasses the ST MC SDK entirely. No current sense, no bus-voltage sense,
  * no position feedback. The motor runs as a synchronous machine: we impose
  * a rotating voltage vector and it follows. Enough to prove the power stage.
  *
  * PROTECTION: there is none in software. The 33 mOhm shunts feed op-amps that
  * are almost certainly unpowered on your board (5 V rail came from the VIPER
  * you removed), and the GANSPIN612 smartSD trips at ~12 A across those shunts
  * -- far above the device's own 3.5-5.5 A rating. The bench supply current
  * limit is your only real protection. Set it to 3.5 A and leave it there.
  ******************************************************************************
  */
#ifndef MOTOR_H
#define MOTOR_H

#include "main.h"
#include <stdint.h>
#include <stdbool.h>

/* ===================== BOARD WIRING =========================================
 * Confirmed against EVLGANSPIN2-3PH Figure 4. This module reclaims all six
 * PWM pins for TIM1 (all AF6):
 *
 *   PA8  TIM1_CH1  -> PWM_UH        PA7  TIM1_CH1N -> PWM_UL
 *   PA9  TIM1_CH2  -> PWM_VH        PB0  TIM1_CH2N -> PWM_VL
 *   PA10 TIM1_CH3  -> PWM_WH        PB1  TIM1_CH3N -> PWM_WL
 *
 *   PA2/PA3   UART_TX / UART_RX   (USART2, already in the .ioc)
 *   PA13/PA14 SWDIO / SWDCLK
 *
 * Routed but unused by this open-loop build:
 *   PA0  CURRENT_U    PC1  CURRENT_V    PC0  CURRENT_W
 *   PA1  VBUS         PA4/PA5 DAC
 *   PA15 HALL_U       PB3  HALL_V       PB10 HALL_W   (TIM2 CH1/CH2/CH3)
 */

/* PA6 is also TIM1_BKIN, so this could become a hardware break input later.
 * For now it is an open-drain GPIO held high (shutdown released), which is
 * what the shared smartSD node needs. */
#define MOT_SD_PORT     GPIOA
#define MOT_SD_PIN      GPIO_PIN_6

#define MOT_FLT_PORT    GPIOA           /* active-low, open-drain              */
#define MOT_FLT_PIN     GPIO_PIN_11

/* Held low (standby) until motor_init() has the PWM pins configured. */
#define MOT_STBY_PORT   GPIOC
#define MOT_STBY_PIN    GPIO_PIN_12

#if !defined(MOT_STBY_PORT)
#warning "MOT_STBY_PORT is not set -- the GANSPIN612 will stay in standby."
#endif

/* Set to 1 if LIN turns out to be active LOW. Verify on a scope with the bus
 * OFF before you ever apply 12 V -- getting this wrong is shoot-through. */
#define MOT_LIN_INVERTED     0

/* ===================== POWER STAGE ======================================== */
#define MOT_PWM_HZ           30000u   /* switching frequency                   */
#define MOT_DEADTIME_NS        300u   /* GANSPIN612 suggested minimum          */
#define MOT_MIN_PULSE_NS       600u   /* GANSPIN612 minimum input pulse width  */
#define MOT_PRECHARGE_MS         3u   /* bootstrap cap charge time             */

/* ===================== MOTOR ============================================== */
#define MOT_POLE_PAIRS           4u   /* <-- SET THIS from your motor          */

/* V/f profile. Modulation index m: 1.0 is the full 12 V bus.
 *
 * With the min-max injection in the modulator, duty spans 0.5 +/- 0.433*m, so
 * m = 1.0 gives 6.7%..93.3% duty -- comfortably inside the pulse-width clamps.
 * Do NOT set M_MAX above 1.0: it overmodulates at 1.155 and the clamps start
 * flat-topping the waveform. */
#define MOT_M_BOOST          0.10f    /* m at standstill, covers winding IR    */
#define MOT_M_MAX            0.60f    /* START HERE. raise once it spins.      */
#define MOT_F_BASE_HZ       100.0f    /* electrical Hz at which m reaches MAX  */

#define MOT_F_MIN_HZ          2.0f    /* frequency we start ramping from       */
#define MOT_RAMP_HZ_PER_S    15.0f    /* electrical Hz per second slew rate    */

typedef enum {
  MOT_IDLE = 0,
  MOT_RUN,
  MOT_FAULT
} mot_state_t;

void        motor_init(void);              /* call after MX_*_Init()           */
bool        motor_start(void);             /* precharge then run; false if FLT */
bool        motor_flt_asserted(void);      /* live FLT pin level               */
void        motor_stop(void);              /* MOE off, all switches off, coast */
void        motor_set_speed_hz(float f);   /* target ELECTRICAL Hz             */
void        motor_set_speed_rpm(float r);  /* target MECHANICAL rpm            */

mot_state_t motor_state(void);
float       motor_speed_hz(void);          /* current (ramped) electrical Hz   */
float       motor_speed_rpm(void);
float       motor_modulation(void);
uint32_t    motor_faults(void);
uint32_t    motor_isr_count(void);         /* for the loop-rate self-check     */
uint32_t    motor_arr(void);
uint32_t    motor_ccr_min(void);
uint32_t    motor_ccr_max(void);
uint32_t    motor_timclk(void);
uint32_t    motor_dtg(void);

#endif /* MOTOR_H */
